# unity-vhsglitch
glitched VHS post-processing shader for Unity3D

This work is licensed under a Creative Commons Attribution 3.0 Unported License.
http://creativecommons.org/licenses/by/3.0/deed.en_GB

You are free:

to copy, distribute, display, and perform the work
to make derivative works
to make commercial use of the work


This post-processing effect requires Unity Pro

USAGE:
Add VHSPostProcessEffect script to camera.

VHS Glitched Video footage by Christopher Huppertz:
https://www.youtube.com/watch?v=9eFVeErnUzg

Licensed under: Creative Commons Attribution licence (reuse allowed)
